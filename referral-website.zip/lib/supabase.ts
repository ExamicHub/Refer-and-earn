import { createClient, type SupabaseClient } from "@supabase/supabase-js"

// Check for required environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    "Missing Supabase configuration. Please set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables.",
  )
}

export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
})

// Server-side client for admin operations
export const createServerClient = () => {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!serviceRoleKey) {
    console.warn("SUPABASE_SERVICE_ROLE_KEY not found, using anon key")
    return createClient(supabaseUrl, supabaseAnonKey)
  }

  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Mock Supabase client for testing without real backend
// export const supabase = {
//   auth: {
//     signUp: async ({ email, password }: { email: string; password: string }) => {
//       // Simulate signup delay
//       await new Promise((resolve) => setTimeout(resolve, 1000))

//       return {
//         data: {
//           user: {
//             id: "mock-user-" + Math.random().toString(36).substr(2, 9),
//             email,
//           },
//         },
//         error: null,
//       }
//     },

//     signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
//       // Simulate login delay
//       await new Promise((resolve) => setTimeout(resolve, 1000))

//       // Mock admin login
//       if (email === "admin@example.com") {
//         return {
//           data: {
//             user: {
//               id: "admin-user-123",
//               email,
//             },
//           },
//           error: null,
//         }
//       }

//       return {
//         data: {
//           user: {
//             id: "mock-user-456",
//             email,
//           },
//         },
//         error: null,
//       }
//     },

//     getUser: async () => {
//       // Check if we're on admin page
//       const isAdminPage = typeof window !== "undefined" && window.location.pathname.includes("/admin")

//       return {
//         data: {
//           user: {
//             id: isAdminPage ? "admin-user-123" : "mock-user-456",
//             email: isAdminPage ? "admin@example.com" : "user@example.com",
//           },
//         },
//         error: null,
//       }
//     },

//     signOut: async () => {
//       return { error: null }
//     },
//   },

//   from: (table: string) => ({
//     select: (columns: string) => ({
//       eq: (column: string, value: any) => ({
//         single: async () => {
//           if (table === "users") {
//             if (value === "admin-user-123") {
//               return {
//                 data: {
//                   id: "admin-user-123",
//                   email: "admin@example.com",
//                   full_name: "Admin User",
//                   referral_code: "ADMIN001",
//                   total_earnings: 0,
//                   available_balance: 0,
//                   total_referrals: 0,
//                   is_admin: true,
//                   created_at: new Date().toISOString(),
//                 },
//               }
//             }
//             return {
//               data: {
//                 id: "mock-user-456",
//                 email: "user@example.com",
//                 full_name: "John Doe",
//                 referral_code: "ABC12345",
//                 total_earnings: 500.0,
//                 available_balance: 300.0,
//                 total_referrals: 5,
//                 is_admin: false,
//                 created_at: new Date().toISOString(),
//               },
//             }
//           }
//           return { data: null }
//         },
//         order: (column: string, options: any) => ({
//           then: async (callback: Function) => {
//             const mockData =
//               table === "users"
//                 ? [
//                     {
//                       id: "user-1",
//                       email: "alice@example.com",
//                       full_name: "Alice Johnson",
//                       referral_code: "ALICE123",
//                       total_earnings: 800.0,
//                       available_balance: 600.0,
//                       total_referrals: 8,
//                       created_at: new Date(Date.now() - 86400000).toISOString(),
//                     },
//                     {
//                       id: "user-2",
//                       email: "bob@example.com",
//                       full_name: "Bob Smith",
//                       referral_code: "BOB456",
//                       total_earnings: 300.0,
//                       available_balance: 200.0,
//                       total_referrals: 3,
//                       created_at: new Date(Date.now() - 172800000).toISOString(),
//                     },
//                   ]
//                 : []

//             return callback({ data: mockData })
//           },
//         }),
//       }),
//       order: (column: string, options: any) => {
//         if (table === "referrals") {
//           return {
//             then: async (callback: Function) => {
//               const mockReferrals = [
//                 {
//                   id: "ref-1",
//                   referred_id: "user-ref-1",
//                   reward_amount: 100.0,
//                   created_at: new Date(Date.now() - 86400000).toISOString(),
//                   users: {
//                     full_name: "Sarah Wilson",
//                     email: "sarah@example.com",
//                   },
//                 },
//                 {
//                   id: "ref-2",
//                   referred_id: "user-ref-2",
//                   reward_amount: 100.0,
//                   created_at: new Date(Date.now() - 172800000).toISOString(),
//                   users: {
//                     full_name: "Mike Brown",
//                     email: "mike@example.com",
//                   },
//                 },
//               ]
//               return callback({ data: mockReferrals })
//             },
//           }
//         }

//         if (table === "withdrawals") {
//           return {
//             then: async (callback: Function) => {
//               const mockWithdrawals = [
//                 {
//                   id: "withdraw-1",
//                   amount: 1000.0,
//                   status: "pending",
//                   requested_at: new Date(Date.now() - 3600000).toISOString(),
//                   processed_at: null,
//                   admin_notes: null,
//                   account_name: "John Doe",
//                   account_number: "1234567890",
//                   bank_name: "First Bank",
//                   users: {
//                     full_name: "John Doe",
//                     email: "user@example.com",
//                   },
//                 },
//                 {
//                   id: "withdraw-2",
//                   amount: 500.0,
//                   status: "approved",
//                   requested_at: new Date(Date.now() - 86400000).toISOString(),
//                   processed_at: new Date(Date.now() - 43200000).toISOString(),
//                   admin_notes: "Approved and processed",
//                   account_name: "Alice Johnson",
//                   account_number: "0987654321",
//                   bank_name: "GTBank",
//                   users: {
//                     full_name: "Alice Johnson",
//                     email: "alice@example.com",
//                   },
//                 },
//               ]
//               return callback({ data: mockWithdrawals })
//             },
//           }
//         }

//         return {
//           then: async (callback: Function) => callback({ data: [] }),
//         }
//       },
//       count: "exact",
//     }),

//     insert: async (data: any) => {
//       // Simulate insert delay
//       await new Promise((resolve) => setTimeout(resolve, 500))
//       return { error: null }
//     },
//   }),

//   rpc: async (functionName: string, params: any) => {
//     // Simulate RPC call delay
//     await new Promise((resolve) => setTimeout(resolve, 500))
//     return { error: null }
//   },
// }
